David Mah
CSC 360 - A02 - T03

Instructions
1. Unzip p3.tar.gz
2. Run "make"
3. You may use your own disk file or file to put in. A sample disk is supplied "disk.IMA". A sample file to copy is supplied "original.txt"
4. To run diskinfo
    Run "./diskinfo <image file>"
5. To run disklist
    Run "./disklist <image file>"
6. To run diskget
    Run "./diskget <image file> <file to get>"
7. To run diskput
    Run "./diskput <image file> <file to put>"

Notes:
If you are copying to the disk image and from the disk image using the supplied sample file, the last line does not have
a new line character.
